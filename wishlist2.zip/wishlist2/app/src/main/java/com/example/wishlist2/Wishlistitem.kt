package com.example.wishlist2

data class WishlistItem(val name: String, val price: String, val url: String)
